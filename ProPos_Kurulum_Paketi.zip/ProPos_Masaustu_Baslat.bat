@echo off
chcp 65001 >nul
set "APP_HTML=%~dp0dist\index.html"
set "APP_URL=file:///%APP_HTML:\=/%"

:: Arka planda Mobil & Disk Senkronizasyon Sunucusunu da sessizce başlat
start "" /b powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Mobil_ve_PC_Canli_Sunucu.ps1"

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="%APP_URL%" --start-maximized
    exit /b 0
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --app="%APP_URL%" --start-maximized
    exit /b 0
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%APP_URL%" --start-maximized
    exit /b 0
)
if exist "%LocalAppData%\Programs\Opera GX\opera.exe" (
    start "" "%LocalAppData%\Programs\Opera GX\opera.exe" --app="%APP_URL%" --start-maximized
    exit /b 0
)
start "" "%APP_HTML%"
