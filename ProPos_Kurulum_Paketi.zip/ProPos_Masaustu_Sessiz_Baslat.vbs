Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")
AppDir = FSO.GetParentFolderName(WScript.ScriptFullName)
HtmlPath = Replace(AppDir & "\dist\index.html", "\", "/")
AppUrl = "file:///" & HtmlPath

' 1. Uygulamayı beklemeden anında (0.1 sn) masaüstü penceresinde aç
Chrome1 = "C:\Program Files\Google\Chrome\Application\chrome.exe"
Chrome2 = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
Chrome3 = WshShell.ExpandEnvironmentStrings("%LocalAppData%") & "\Google\Chrome\Application\chrome.exe"
OperaGX = WshShell.ExpandEnvironmentStrings("%LocalAppData%") & "\Programs\Opera GX\opera.exe"

If FSO.FileExists(Chrome1) Then
    WshShell.Run """" & Chrome1 & """ --app=""" & AppUrl & """ --start-maximized", 1, False
ElseIf FSO.FileExists(Chrome2) Then
    WshShell.Run """" & Chrome2 & """ --app=""" & AppUrl & """ --start-maximized", 1, False
ElseIf FSO.FileExists(Chrome3) Then
    WshShell.Run """" & Chrome3 & """ --app=""" & AppUrl & """ --start-maximized", 1, False
ElseIf FSO.FileExists(OperaGX) Then
    WshShell.Run """" & OperaGX & """ --app=""" & AppUrl & """ --start-maximized", 1, False
Else
    WshShell.Run """" & AppDir & "\dist\index.html""", 1, False
End If

' 2. Mobil ve Disk Senkronizasyon Sunucusunu arka planda sessizce başlat
WshShell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & AppDir & "\Mobil_ve_PC_Canli_Sunucu.ps1""", 0, False
