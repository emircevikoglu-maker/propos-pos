@echo off
title ProPos - Masaustu Kisayolu Olusturucu
set "APP_HTML=%~dp0dist\index.html"
set "APP_URL=file:///%APP_HTML:\=/%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $desktop = [Environment]::GetFolderPath('Desktop'); ^
   $lnk = $ws.CreateShortcut((Join-Path $desktop 'ProPos Kurumsal POS.lnk')); ^
   if (Test-Path 'C:\Program Files\Google\Chrome\Application\chrome.exe') { ^
     $lnk.TargetPath = 'C:\Program Files\Google\Chrome\Application\chrome.exe'; ^
     $lnk.Arguments = '--app=\"%APP_URL%\" --start-maximized'; ^
   } else { ^
     $lnk.TargetPath = 'wscript.exe'; ^
     $lnk.Arguments = '\"%~dp0ProPos_Masaustu_Sessiz_Baslat.vbs\"'; ^
   } ^
   $lnk.WorkingDirectory = '%~dp0dist'; ^
   $lnk.Description = 'ProPos - Kurumsal POS & Bulut ERP Sistemi'; ^
   $lnk.IconLocation = 'shell32.dll,43'; ^
   $lnk.Save()"

echo.
echo [OK] "ProPos Kurumsal POS" kisayolu Masaustunuze guncellendi!
pause
