﻿$ErrorActionPreference = "Continue"
$projDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$distDir = Join-Path $projDir "dist"
$dbFile = Join-Path $projDir "ProPos_Canli_Veritabani.json"
$tenantsDir = Join-Path $projDir "tenants"
$tenantsRegistryFile = Join-Path $projDir "ProPos_Bayi_Musteriler.json"
$seedFile = Join-Path $distDir "ProPos_Tam_Sistem_Yedegi_2026-11-14.json"
$dllPath = Join-Path $projDir "ProPosSyncServerV5.dll"

if (-not (Test-Path $tenantsDir)) {
    New-Item -ItemType Directory -Path $tenantsDir -Force | Out-Null
}
if (-not (Test-Path $dbFile) -and (Test-Path $seedFile)) {
    Copy-Item $seedFile $dbFile -Force
}

$csharpCode = @"
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

public class TenantState {
    public string Json = "{}";
    public long Rev = 1;
    public string UpdatedBy = "init";
    public string FilePath = "";
}

public class ProPosSyncServerV3 {
    private TcpListener listenerMain;
    private TcpListener listenerLegacy;
    private string projDir;
    private string distDir;
    private string defaultDbFile;
    private string tenantsDir;
    private string tenantsRegistryFile;
    private object dbLock = new object();
    private Dictionary<string, TenantState> tenantStates = new Dictionary<string, TenantState>(StringComparer.OrdinalIgnoreCase);
    private string cachedRegistryJson = "[]";
    private string lanIp = "127.0.0.1";

    public ProPosSyncServerV3(int mainPort, int legacyPort, string projectPath, string distPath, string dbPath, string tenantsFolderPath, string registryPath, string ip) {
        projDir = projectPath;
        distDir = distPath;
        defaultDbFile = dbPath;
        tenantsDir = tenantsFolderPath;
        tenantsRegistryFile = registryPath;
        lanIp = ip;

        if (!Directory.Exists(tenantsDir)) {
            Directory.CreateDirectory(tenantsDir);
        }
        if (File.Exists(tenantsRegistryFile)) {
            try { cachedRegistryJson = File.ReadAllText(tenantsRegistryFile, Encoding.UTF8); } catch { cachedRegistryJson = "[]"; }
        }
        GetOrLoadTenant("DEFAULT");

        listenerMain = new TcpListener(IPAddress.Any, mainPort);
        listenerLegacy = new TcpListener(IPAddress.Any, legacyPort);
    }

    private string NormalizeTenantId(string rawId) {
        if (string.IsNullOrWhiteSpace(rawId)) return "DEFAULT";
        string decoded = Uri.UnescapeDataString(rawId).Trim().ToUpperInvariant();
        if (decoded == "DEFAULT" || decoded == "PICKYS-MASTER" || decoded == "MASTER") return "DEFAULT";
        string clean = Regex.Replace(decoded, "[^A-Z0-9_-]", "");
        return string.IsNullOrEmpty(clean) ? "DEFAULT" : clean;
    }

    private TenantState GetOrLoadTenant(string tenantId) {
        string norm = NormalizeTenantId(tenantId);
        lock (dbLock) {
            TenantState st;
            if (tenantStates.TryGetValue(norm, out st)) {
                return st;
            }
            st = new TenantState();
            st.FilePath = (norm == "DEFAULT") ? defaultDbFile : Path.Combine(tenantsDir, norm + ".json");
            if (File.Exists(st.FilePath)) {
                try { st.Json = File.ReadAllText(st.FilePath, Encoding.UTF8); } catch { st.Json = "{}"; }
            } else if (File.Exists(defaultDbFile)) {
                try { st.Json = File.ReadAllText(defaultDbFile, Encoding.UTF8); } catch { st.Json = "{}"; }
            }
            st.Rev = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            tenantStates[norm] = st;
            return st;
        }
    }

    private string GetQueryParam(string rawUrl, string key) {
        int qIdx = rawUrl.IndexOf('?');
        if (qIdx < 0) return "";
        string query = rawUrl.Substring(qIdx + 1);
        string[] parts = query.Split('&');
        foreach (string p in parts) {
            string[] kv = p.Split(new char[] { '=' }, 2);
            if (kv.Length == 2 && string.Equals(kv[0], key, StringComparison.OrdinalIgnoreCase)) {
                return Uri.UnescapeDataString(kv[1]);
            }
        }
        return "";
    }

    public void Start() {
        listenerMain.Start();
        try {
            listenerLegacy.Start();
            Task.Run(() => AcceptLoop(listenerLegacy));
        } catch { }
        AcceptLoop(listenerMain);
    }

    private void AcceptLoop(TcpListener listener) {
        while (true) {
            try {
                TcpClient client = listener.AcceptTcpClient();
                Task.Run(() => HandleClient(client));
            } catch { }
        }
    }

    private void HandleClient(TcpClient client) {
        using (client)
        using (NetworkStream stream = client.GetStream()) {
            stream.ReadTimeout = 15000;
            stream.WriteTimeout = 15000;
            try {
                MemoryStream ms = new MemoryStream();
                byte[] buf = new byte[8192];
                int headerEnd = -1;
                while (true) {
                    int r = stream.Read(buf, 0, buf.Length);
                    if (r <= 0) break;
                    ms.Write(buf, 0, r);
                    byte[] arr = ms.ToArray();
                    headerEnd = FindHeaderEnd(arr);
                    if (headerEnd != -1) break;
                    if (arr.Length > 65536) break;
                }
                if (headerEnd == -1) return;

                byte[] allBytes = ms.ToArray();
                string headerText = Encoding.UTF8.GetString(allBytes, 0, headerEnd);
                string[] lines = headerText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                if (lines.Length == 0) return;

                string[] reqParts = lines[0].Split(' ');
                if (reqParts.Length < 2) return;
                string method = reqParts[0].ToUpperInvariant();
                string rawUrl = reqParts[1];
                string pathOnly = rawUrl.Split('?')[0];

                int contentLength = 0;
                bool acceptsGzip = false;
                foreach (string line in lines) {
                    if (line.StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase)) {
                        int.TryParse(line.Substring(15).Trim(), out contentLength);
                    } else if (line.StartsWith("Accept-Encoding:", StringComparison.OrdinalIgnoreCase)) {
                        if (line.IndexOf("gzip", StringComparison.OrdinalIgnoreCase) >= 0) {
                            acceptsGzip = true;
                        }
                    }
                }

                int bodyOffset = headerEnd + 4;
                int alreadyReadBody = allBytes.Length - bodyOffset;
                MemoryStream bodyStream = new MemoryStream();
                if (alreadyReadBody > 0) {
                    bodyStream.Write(allBytes, bodyOffset, alreadyReadBody);
                }
                while (bodyStream.Length < contentLength) {
                    int toRead = Math.Min(buf.Length, contentLength - (int)bodyStream.Length);
                    int r = stream.Read(buf, 0, toRead);
                    if (r <= 0) break;
                    bodyStream.Write(buf, 0, r);
                }
                string bodyText = Encoding.UTF8.GetString(bodyStream.ToArray());

                if (method == "OPTIONS") {
                    WriteResponse(stream, "200 OK", "text/plain", new byte[0], null);
                    return;
                }

                if (pathOnly == "/api/info") {
                    TenantState st = GetOrLoadTenant(GetQueryParam(rawUrl, "tenantId"));
                    string infoJson = "{\"ok\":true,\"lanIp\":\"" + lanIp + "\",\"port\":8586,\"rev\":" + st.Rev + ",\"updatedBy\":\"" + st.UpdatedBy + "\"}";
                    WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(infoJson), null);
                    return;
                }

                if (pathOnly == "/api/tenants") {
                    if (method == "GET") {
                        string reg;
                        lock (dbLock) { reg = cachedRegistryJson; }
                        string outJson = "{\"ok\":true,\"lanIp\":\"" + lanIp + "\",\"tenants\":" + reg + "}";
                        WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(outJson), null);
                        return;
                    } else if (method == "POST") {
                        if (!string.IsNullOrWhiteSpace(bodyText) && bodyText.Trim().StartsWith("[")) {
                            lock (dbLock) {
                                cachedRegistryJson = bodyText;
                                try { File.WriteAllText(tenantsRegistryFile, cachedRegistryJson, new UTF8Encoding(false)); } catch { }
                            }
                            WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes("{\"ok\":true}"), null);
                            return;
                        }
                        WriteResponse(stream, "400 Bad Request", "application/json", Encoding.UTF8.GetBytes("{\"ok\":false}"), null);
                        return;
                    }
                }

                if (pathOnly == "/api/sync") {
                    string reqTenant = NormalizeTenantId(GetQueryParam(rawUrl, "tenantId"));
                    TenantState st = GetOrLoadTenant(reqTenant);
                    if (method == "GET") {
                        string respJson;
                        lock (dbLock) {
                            respJson = "{\"ok\":true,\"tenantId\":\"" + reqTenant + "\",\"rev\":" + st.Rev + ",\"updatedBy\":\"" + st.UpdatedBy + "\",\"lanIp\":\"" + lanIp + "\",\"registry\":" + cachedRegistryJson + ",\"data\":" + st.Json + "}";
                        }
                        WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(respJson), null);
                        return;
                    } else if (method == "POST") {
                        if (!string.IsNullOrWhiteSpace(bodyText) && bodyText.Contains("\"tables\"") && bodyText.Contains("\"products\"")) {
                            string devId = GetQueryParam(rawUrl, "deviceId");
                            if (string.IsNullOrEmpty(devId)) devId = "unknown";
                            lock (dbLock) {
                                st.Json = bodyText;
                                st.Rev = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                                st.UpdatedBy = devId;
                                try {
                                    string tmpFile = st.FilePath + ".tmp";
                                    File.WriteAllText(tmpFile, st.Json, new UTF8Encoding(false));
                                    if (File.Exists(st.FilePath)) File.Delete(st.FilePath);
                                    File.Move(tmpFile, st.FilePath);
                                } catch {
                                    try { File.WriteAllText(st.FilePath, st.Json, new UTF8Encoding(false)); } catch { }
                                }
                            }
                            string okJson = "{\"ok\":true,\"tenantId\":\"" + reqTenant + "\",\"rev\":" + st.Rev + ",\"updatedBy\":\"" + st.UpdatedBy + "\"}";
                            WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(okJson), null);
                            return;
                        }
                        WriteResponse(stream, "400 Bad Request", "application/json", Encoding.UTF8.GetBytes("{\"ok\":false}"), null);
                        return;
                    }
                }

                if (pathOnly == "/api/apply-update" && method == "POST") {
                    if (!string.IsNullOrWhiteSpace(bodyText) && bodyText.Contains("<html")) {
                        lock (dbLock) {
                            try {
                                string distHtml = Path.Combine(distDir, "index.html");
                                string rootHtml = Path.Combine(projDir, "ProPos_Hazir_Uygulama.html");
                                File.WriteAllText(distHtml, bodyText, new UTF8Encoding(false));
                                File.WriteAllText(rootHtml, bodyText, new UTF8Encoding(false));
                            } catch { }
                        }
                        WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes("{\"ok\":true}"), null);
                        return;
                    }
                    WriteResponse(stream, "400 Bad Request", "application/json", Encoding.UTF8.GetBytes("{\"ok\":false}"), null);
                    return;
                }

                if (pathOnly == "/api/prepare-github" && method == "POST") {
                    if (!string.IsNullOrWhiteSpace(bodyText)) {
                        lock (dbLock) {
                            try {
                                string ghDir = Path.Combine(projDir, "github-yayin");
                                if (!Directory.Exists(ghDir)) Directory.CreateDirectory(ghDir);
                                File.WriteAllText(Path.Combine(ghDir, "version.json"), bodyText, new UTF8Encoding(false));
                                File.WriteAllText(Path.Combine(distDir, "version.json"), bodyText, new UTF8Encoding(false));
                                File.WriteAllText(Path.Combine(projDir, "version.json"), bodyText, new UTF8Encoding(false));
                                string srcHtml = Path.Combine(distDir, "index.html");
                                if (File.Exists(srcHtml)) {
                                    File.Copy(srcHtml, Path.Combine(ghDir, "index.html"), true);
                                }
                            } catch { }
                        }
                        WriteResponse(stream, "200 OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes("{\"ok\":true}"), null);
                        return;
                    }
                }

                if (pathOnly == "/api/package") {
                    string reqTenant = NormalizeTenantId(GetQueryParam(rawUrl, "tenantId"));
                    string bizName = GetQueryParam(rawUrl, "businessName");
                    string ghRepo = GetQueryParam(rawUrl, "githubRepo");
                    string appVer = GetQueryParam(rawUrl, "appVersion");
                    if (string.IsNullOrWhiteSpace(bizName)) bizName = reqTenant;
                    string safeSlug = Regex.Replace(bizName, "[^a-zA-Z0-9_-]", "_");
                    if (string.IsNullOrWhiteSpace(safeSlug)) safeSlug = reqTenant;

                    TenantState st = GetOrLoadTenant(reqTenant);
                    byte[] zipBytes = BuildCustomerPackageZip(reqTenant, bizName, st.Json, ghRepo, appVer);
                    string extraHeader = "Content-Disposition: attachment; filename=\"ProPos_Kurulum_Paketi_" + safeSlug + "_" + reqTenant + ".zip\"\r\n";
                    WriteResponse(stream, "200 OK", "application/zip", zipBytes, extraHeader);
                    return;
                }

                if (pathOnly == "/" || pathOnly == "") pathOnly = "/index.html";
                string safeRel = pathOnly.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
                string fullPath = Path.Combine(distDir, safeRel);
                if (!File.Exists(fullPath)) {
                    fullPath = Path.Combine(distDir, "index.html");
                }

                string ext = Path.GetExtension(fullPath).ToLowerInvariant();
                string mime = "text/html; charset=utf-8";
                if (ext == ".json") mime = "application/json; charset=utf-8";
                else if (ext == ".js") mime = "application/javascript; charset=utf-8";
                else if (ext == ".svg") mime = "image/svg+xml";
                else if (ext == ".css") mime = "text/css; charset=utf-8";

                byte[] fileBytes = File.ReadAllBytes(fullPath);
                if (acceptsGzip && fileBytes.Length > 4096 && ext != ".zip") {
                    using (MemoryStream gzMs = new MemoryStream()) {
                        using (GZipStream gz = new GZipStream(gzMs, CompressionMode.Compress, true)) {
                            gz.Write(fileBytes, 0, fileBytes.Length);
                        }
                        byte[] gzBytes = gzMs.ToArray();
                        WriteResponse(stream, "200 OK", mime, gzBytes, "Content-Encoding: gzip\r\n");
                    }
                } else {
                    WriteResponse(stream, "200 OK", mime, fileBytes, null);
                }
                try {
                    client.Client.Shutdown(SocketShutdown.Send);
                    stream.ReadTimeout = 800;
                    byte[] drain = new byte[512];
                    while (stream.Read(drain, 0, drain.Length) > 0) { }
                } catch { }
            } catch { }
        }
    }

    private byte[] BuildCustomerPackageZip(string tenantId, string businessName, string tenantDbJson, string githubRepo, string appVersion) {
        using (MemoryStream zipMs = new MemoryStream()) {
            using (ZipArchive archive = new ZipArchive(zipMs, ZipArchiveMode.Create, true)) {
                string indexHtmlPath = Path.Combine(distDir, "index.html");
                if (File.Exists(indexHtmlPath)) {
                    string html = File.ReadAllText(indexHtmlPath, Encoding.UTF8);
                    string safeRepo = (githubRepo ?? "").Replace("\"", "");
                    string safeVer = string.IsNullOrWhiteSpace(appVersion) ? "2.4.0" : appVersion.Replace("\"", "");
                    string tenantBootScript = "<script>window.__PROPOS_LOCKED_TENANT__ = \"" + tenantId + "\"; window.__PROPOS_APP_VERSION__ = \"" + safeVer + "\"; window.__PROPOS_GITHUB_REPO__ = \"" + safeRepo + "\"; try { localStorage.setItem(\"propos_active_tenant_id\", \"" + tenantId + "\"); localStorage.setItem(\"propos_app_version\", \"" + safeVer + "\"); if (\"" + safeRepo + "\" !== \"\") localStorage.setItem(\"propos_github_repo\", \"" + safeRepo + "\"); } catch(e){}</script>\n</head>";
                    html = html.Replace("</head>", tenantBootScript);
                    AddTextEntry(archive, "dist/index.html", html);
                    AddTextEntry(archive, "ProPos_Hazir_Uygulama.html", html);
                }

                AddTextEntry(archive, "ProPos_Canli_Veritabani.json", tenantDbJson);
                AddTextEntry(archive, "tenants/" + tenantId + ".json", tenantDbJson);
                AddTextEntry(archive, "ProPos_Bayi_Musteriler.json", cachedRegistryJson);

                string[] copyFiles = new string[] {
                    "ProPos_Masaustu_Baslat.bat",
                    "ProPos_Masaustu_Sessiz_Baslat.vbs",
                    "Masaustune_Kisayol_Olustur.bat",
                    "Mobil_ve_PC_Canli_Sunucu.ps1"
                };
                foreach (string f in copyFiles) {
                    string fp = Path.Combine(projDir, f);
                    if (File.Exists(fp)) {
                        AddBytesEntry(archive, f, File.ReadAllBytes(fp));
                    }
                }

                string readme = "=================================================================\r\n" +
                                "   " + businessName.ToUpperInvariant() + " - PROPOS KURUMSAL POS & MOBIL KURULUM PAKETI\r\n" +
                                "   ISLETME KODU (TENANT ID): " + tenantId + "\r\n" +
                                "=================================================================\r\n\r\n" +
                                "1. BILGISAYARDA KURULUM (TEK TIK):\r\n" +
                                "   - Bu ZIP paketi icindeki tum dosyalari bir klasore cikarin.\r\n" +
                                "   - 'Masaustune_Kisayol_Olustur.bat' dosyasina cift tiklayin.\r\n" +
                                "   - Masaustunuze gelen 'ProPos Kurumsal POS' simgesinden uygulamayi hemen kullanabilirsiniz.\r\n\r\n" +
                                "2. TELEFON VE TABLETTEN CANLI SENKRONIZE KULLANIM:\r\n" +
                                "   - Uygulamanin ust barindaki 'PC & Mobil Canli Senkron' butonuna tiklayin.\r\n" +
                                "   - Ekranda cikan QR kodu telefonunuzun kamerasiyla okutarak aninda baglanin!\r\n";
                AddTextEntry(archive, "MUSTERI_KURULUM_REHBERI.txt", readme);
            }
            return zipMs.ToArray();
        }
    }

    private void AddTextEntry(ZipArchive archive, string entryName, string content) {
        byte[] bytes = new UTF8Encoding(false).GetBytes(content);
        AddBytesEntry(archive, entryName, bytes);
    }

    private void AddBytesEntry(ZipArchive archive, string entryName, byte[] bytes) {
        ZipArchiveEntry entry = archive.CreateEntry(entryName, CompressionLevel.Fastest);
        using (Stream s = entry.Open()) {
            s.Write(bytes, 0, bytes.Length);
        }
    }

    private int FindHeaderEnd(byte[] arr) {
        for (int i = 0; i <= arr.Length - 4; i++) {
            if (arr[i] == 13 && arr[i+1] == 10 && arr[i+2] == 13 && arr[i+3] == 10) return i;
        }
        return -1;
    }

    private void WriteResponse(NetworkStream stream, string status, string contentType, byte[] body, string extraHeaders) {
        string headers = "HTTP/1.1 " + status + "\r\n" +
                         "Content-Type: " + contentType + "\r\n" +
                         "Content-Length: " + body.Length + "\r\n" +
                         "Access-Control-Allow-Origin: *\r\n" +
                         "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                         "Access-Control-Allow-Headers: Content-Type, Cache-Control, Pragma\r\n" +
                         "Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n" +
                         "Pragma: no-cache\r\n" +
                         "Expires: 0\r\n" +
                         (extraHeaders ?? "") +
                         "Connection: close\r\n\r\n";
        byte[] headerBytes = Encoding.UTF8.GetBytes(headers);
        stream.Write(headerBytes, 0, headerBytes.Length);
        if (body.Length > 0) {
            int offset = 0;
            int chunkSize = 32768;
            while (offset < body.Length) {
                int toWrite = Math.Min(chunkSize, body.Length - offset);
                stream.Write(body, offset, toWrite);
                offset += toWrite;
            }
        }
        stream.Flush();
    }
}
"@

if (Test-Path $dllPath) {
    Add-Type -Path $dllPath
} else {
    Add-Type -TypeDefinition $csharpCode -ReferencedAssemblies @("System.IO.Compression.dll", "System.IO.Compression.FileSystem.dll") -Language CSharp -OutputAssembly $dllPath
    Add-Type -Path $dllPath
}

$lanIp = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notmatch "^127\.|^169\.254\." } | Select-Object -First 1 -ExpandProperty IPAddress)
if (-not $lanIp) { $lanIp = "127.0.0.1" }

$server = New-Object ProPosSyncServerV3(8586, 8585, $projDir, $distDir, $dbFile, $tenantsDir, $tenantsRegistryFile, $lanIp)
$server.Start()
